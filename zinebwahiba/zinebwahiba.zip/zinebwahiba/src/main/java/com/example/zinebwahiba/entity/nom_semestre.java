package com.example.zinebwahiba.entity;

public enum nom_semestre {
    S1,S2,S3,S4,S5
}
