package com.example.zinebwahiba.dao;

import com.example.zinebwahiba.entity.Module;
import org.springframework.data.jpa.repository.JpaRepository;

public interface module extends JpaRepository<Module, Integer> {
}
