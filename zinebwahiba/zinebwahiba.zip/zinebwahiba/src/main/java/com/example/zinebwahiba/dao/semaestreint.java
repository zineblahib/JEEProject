package com.example.zinebwahiba.dao;


import com.example.zinebwahiba.entity.Semestre;
import org.springframework.data.jpa.repository.JpaRepository;

public interface semaestreint extends JpaRepository<Semestre, Integer> {
}
