package com.example.zinebwahiba.dao;


import com.example.zinebwahiba.entity.Element;
import org.springframework.data.jpa.repository.JpaRepository;

public interface elementInt extends JpaRepository<Element, Integer> {
}
