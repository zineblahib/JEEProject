package com.example.zinebwahiba.metier;

import com.example.zinebwahiba.entity.Etudiant;
import com.example.zinebwahiba.entity.Professeur;

import java.util.List;

public interface EtudiantMetier {
    List<Etudiant> getAll();
}
