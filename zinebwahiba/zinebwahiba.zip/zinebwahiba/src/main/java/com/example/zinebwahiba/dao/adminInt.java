package com.example.zinebwahiba.dao;

import com.example.zinebwahiba.entity.Admin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface adminInt extends JpaRepository<Admin, Integer> {

}
