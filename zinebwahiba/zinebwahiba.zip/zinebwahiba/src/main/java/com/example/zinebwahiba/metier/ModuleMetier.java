package com.example.zinebwahiba.metier;

import com.example.zinebwahiba.entity.Module;

import java.util.List;

public interface ModuleMetier {
     List<Module> getAll() ;

}
