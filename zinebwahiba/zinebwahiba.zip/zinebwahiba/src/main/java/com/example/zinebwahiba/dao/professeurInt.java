package com.example.zinebwahiba.dao;

import com.example.zinebwahiba.entity.Professeur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface professeurInt extends JpaRepository<Professeur, Integer> {

}
