package com.example.zinebwahiba.metier;

import com.example.zinebwahiba.entity.Element;
import com.example.zinebwahiba.entity.Filiere;

import java.util.List;

public interface FiliereMetier {
    List<Filiere> getAll();
}
