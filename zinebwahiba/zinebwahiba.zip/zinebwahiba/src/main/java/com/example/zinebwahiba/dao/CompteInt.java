package com.example.zinebwahiba.dao;


import com.example.zinebwahiba.entity.Compte;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompteInt extends JpaRepository<Compte, Integer> {
}
