package com.example.zinebwahiba.dao;

import com.example.zinebwahiba.entity.Note;
import org.springframework.data.jpa.repository.JpaRepository;

public interface noteInt extends JpaRepository<Note, Integer> {
}
